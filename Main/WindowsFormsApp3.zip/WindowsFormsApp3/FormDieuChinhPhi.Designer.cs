﻿namespace WindowsFormsApp3
{
    partial class FormDieuChinhPhi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbTienNuoc = new System.Windows.Forms.TextBox();
            this.tbTienDien = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbPhiSinhHoat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbTienXeMay = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbTienXeDap = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbTienXe15Tan = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(173, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tiền nước";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(352, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(219, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Điều Chỉnh Phí";
            // 
            // tbTienNuoc
            // 
            this.tbTienNuoc.Location = new System.Drawing.Point(489, 110);
            this.tbTienNuoc.Multiline = true;
            this.tbTienNuoc.Name = "tbTienNuoc";
            this.tbTienNuoc.Size = new System.Drawing.Size(260, 38);
            this.tbTienNuoc.TabIndex = 2;
            // 
            // tbTienDien
            // 
            this.tbTienDien.Location = new System.Drawing.Point(489, 163);
            this.tbTienDien.Multiline = true;
            this.tbTienDien.Name = "tbTienDien";
            this.tbTienDien.Size = new System.Drawing.Size(260, 38);
            this.tbTienDien.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(173, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 37);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tiền điện";
            // 
            // tbPhiSinhHoat
            // 
            this.tbPhiSinhHoat.Location = new System.Drawing.Point(489, 221);
            this.tbPhiSinhHoat.Multiline = true;
            this.tbPhiSinhHoat.Name = "tbPhiSinhHoat";
            this.tbPhiSinhHoat.Size = new System.Drawing.Size(260, 38);
            this.tbPhiSinhHoat.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(173, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(185, 37);
            this.label4.TabIndex = 5;
            this.label4.Text = "Phí sinh hoạt";
            // 
            // tbTienXeMay
            // 
            this.tbTienXeMay.Location = new System.Drawing.Point(489, 278);
            this.tbTienXeMay.Multiline = true;
            this.tbTienXeMay.Name = "tbTienXeMay";
            this.tbTienXeMay.Size = new System.Drawing.Size(260, 38);
            this.tbTienXeMay.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(173, 278);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(178, 37);
            this.label5.TabIndex = 7;
            this.label5.Text = "Tiền xe máy";
            // 
            // tbTienXeDap
            // 
            this.tbTienXeDap.Location = new System.Drawing.Point(489, 336);
            this.tbTienXeDap.Multiline = true;
            this.tbTienXeDap.Name = "tbTienXeDap";
            this.tbTienXeDap.Size = new System.Drawing.Size(260, 38);
            this.tbTienXeDap.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(173, 336);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 37);
            this.label6.TabIndex = 9;
            this.label6.Text = "Tiền xe đạp";
            // 
            // tbTienXe15Tan
            // 
            this.tbTienXe15Tan.Location = new System.Drawing.Point(489, 400);
            this.tbTienXe15Tan.Multiline = true;
            this.tbTienXe15Tan.Name = "tbTienXe15Tan";
            this.tbTienXe15Tan.Size = new System.Drawing.Size(260, 38);
            this.tbTienXe15Tan.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(173, 399);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(280, 37);
            this.label7.TabIndex = 11;
            this.label7.Text = "Tiền xe dưới 1,5 tấn";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.Location = new System.Drawing.Point(273, 491);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 55);
            this.button1.TabIndex = 13;
            this.button1.Text = "Thoát";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.Location = new System.Drawing.Point(511, 491);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 55);
            this.button2.TabIndex = 14;
            this.button2.Text = "Xác nhận";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormDieuChinhPhi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(987, 588);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbTienXe15Tan);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbTienXeDap);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbTienXeMay);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbPhiSinhHoat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbTienDien);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbTienNuoc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormDieuChinhPhi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormDieuChinhPhi";
            this.Load += new System.EventHandler(this.FormDieuChinhPhi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbTienNuoc;
        private System.Windows.Forms.TextBox tbTienDien;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbPhiSinhHoat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbTienXeMay;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbTienXeDap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbTienXe15Tan;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}