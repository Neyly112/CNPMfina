﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLiCanHo
{
    internal class connectionString
    {
        public static string ConnectionString = @"Data Source=MSI;Initial Catalog=QLCH1;Integrated Security=True;";
    }
}
