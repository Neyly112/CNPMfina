﻿namespace WindowsFormsApp3
{
    partial class FormTongTien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbXeDuoi15Tan = new System.Windows.Forms.Label();
            this.lbXeDap = new System.Windows.Forms.Label();
            this.lbXeMay = new System.Windows.Forms.Label();
            this.lbTienXe = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbTienThuePhong = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbNgayLap = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbMaCanHo = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbTongTien = new System.Windows.Forms.Label();
            this.lbPhiSinhHoat = new System.Windows.Forms.Label();
            this.lbTongTienNuoc = new System.Windows.Forms.Label();
            this.lbTongTienDien = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbXeDuoi15Tan
            // 
            this.lbXeDuoi15Tan.AutoSize = true;
            this.lbXeDuoi15Tan.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbXeDuoi15Tan.Location = new System.Drawing.Point(561, 367);
            this.lbXeDuoi15Tan.Name = "lbXeDuoi15Tan";
            this.lbXeDuoi15Tan.Size = new System.Drawing.Size(131, 37);
            this.lbXeDuoi15Tan.TabIndex = 61;
            this.lbXeDuoi15Tan.Text = "Tiền xe: ";
            // 
            // lbXeDap
            // 
            this.lbXeDap.AutoSize = true;
            this.lbXeDap.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbXeDap.Location = new System.Drawing.Point(386, 367);
            this.lbXeDap.Name = "lbXeDap";
            this.lbXeDap.Size = new System.Drawing.Size(131, 37);
            this.lbXeDap.TabIndex = 60;
            this.lbXeDap.Text = "Tiền xe: ";
            // 
            // lbXeMay
            // 
            this.lbXeMay.AutoSize = true;
            this.lbXeMay.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbXeMay.Location = new System.Drawing.Point(201, 367);
            this.lbXeMay.Name = "lbXeMay";
            this.lbXeMay.Size = new System.Drawing.Size(131, 37);
            this.lbXeMay.TabIndex = 59;
            this.lbXeMay.Text = "Tiền xe: ";
            // 
            // lbTienXe
            // 
            this.lbTienXe.AutoSize = true;
            this.lbTienXe.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbTienXe.Location = new System.Drawing.Point(498, 319);
            this.lbTienXe.Name = "lbTienXe";
            this.lbTienXe.Size = new System.Drawing.Size(215, 37);
            this.lbTienXe.TabIndex = 58;
            this.lbTienXe.Text = "Tổng tiền điện:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.Location = new System.Drawing.Point(232, 319);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 37);
            this.label11.TabIndex = 57;
            this.label11.Text = "Tiền xe: ";
            // 
            // lbTienThuePhong
            // 
            this.lbTienThuePhong.AutoSize = true;
            this.lbTienThuePhong.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbTienThuePhong.Location = new System.Drawing.Point(498, 471);
            this.lbTienThuePhong.Name = "lbTienThuePhong";
            this.lbTienThuePhong.Size = new System.Drawing.Size(215, 37);
            this.lbTienThuePhong.TabIndex = 56;
            this.lbTienThuePhong.Text = "Tổng tiền điện:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.Location = new System.Drawing.Point(232, 471);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(245, 37);
            this.label9.TabIndex = 55;
            this.label9.Text = "Tiền thuê phòng: ";
            // 
            // lbNgayLap
            // 
            this.lbNgayLap.AutoSize = true;
            this.lbNgayLap.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbNgayLap.Location = new System.Drawing.Point(498, 414);
            this.lbNgayLap.Name = "lbNgayLap";
            this.lbNgayLap.Size = new System.Drawing.Size(215, 37);
            this.lbNgayLap.TabIndex = 54;
            this.lbNgayLap.Text = "Tổng tiền điện:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(232, 414);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 37);
            this.label5.TabIndex = 53;
            this.label5.Text = "Ngày lập";
            // 
            // lbMaCanHo
            // 
            this.lbMaCanHo.AutoSize = true;
            this.lbMaCanHo.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbMaCanHo.Location = new System.Drawing.Point(498, 99);
            this.lbMaCanHo.Name = "lbMaCanHo";
            this.lbMaCanHo.Size = new System.Drawing.Size(179, 37);
            this.lbMaCanHo.TabIndex = 52;
            this.lbMaCanHo.Text = "Mã Căn Hộ:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(232, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 37);
            this.label4.TabIndex = 51;
            this.label4.Text = "Mã căn hộ: ";
            // 
            // lbTongTien
            // 
            this.lbTongTien.AutoSize = true;
            this.lbTongTien.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbTongTien.Location = new System.Drawing.Point(498, 527);
            this.lbTongTien.Name = "lbTongTien";
            this.lbTongTien.Size = new System.Drawing.Size(215, 37);
            this.lbTongTien.TabIndex = 50;
            this.lbTongTien.Text = "Tổng tiền điện:";
            // 
            // lbPhiSinhHoat
            // 
            this.lbPhiSinhHoat.AutoSize = true;
            this.lbPhiSinhHoat.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbPhiSinhHoat.Location = new System.Drawing.Point(498, 264);
            this.lbPhiSinhHoat.Name = "lbPhiSinhHoat";
            this.lbPhiSinhHoat.Size = new System.Drawing.Size(215, 37);
            this.lbPhiSinhHoat.TabIndex = 49;
            this.lbPhiSinhHoat.Text = "Tổng tiền điện:";
            // 
            // lbTongTienNuoc
            // 
            this.lbTongTienNuoc.AutoSize = true;
            this.lbTongTienNuoc.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbTongTienNuoc.Location = new System.Drawing.Point(498, 209);
            this.lbTongTienNuoc.Name = "lbTongTienNuoc";
            this.lbTongTienNuoc.Size = new System.Drawing.Size(215, 37);
            this.lbTongTienNuoc.TabIndex = 48;
            this.lbTongTienNuoc.Text = "Tổng tiền điện:";
            // 
            // lbTongTienDien
            // 
            this.lbTongTienDien.AutoSize = true;
            this.lbTongTienDien.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbTongTienDien.Location = new System.Drawing.Point(498, 157);
            this.lbTongTienDien.Name = "lbTongTienDien";
            this.lbTongTienDien.Size = new System.Drawing.Size(215, 37);
            this.lbTongTienDien.TabIndex = 47;
            this.lbTongTienDien.Text = "Tổng tiền điện:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(232, 527);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 37);
            this.label2.TabIndex = 46;
            this.label2.Text = "Tổng tiền:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.Location = new System.Drawing.Point(505, 584);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(243, 48);
            this.button2.TabIndex = 45;
            this.button2.Text = "Xác nhận";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.Location = new System.Drawing.Point(266, 584);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 48);
            this.button1.TabIndex = 44;
            this.button1.Text = "Thoát";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(402, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 37);
            this.label1.TabIndex = 43;
            this.label1.Text = "Tổng Tiền";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(232, 264);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(185, 37);
            this.label8.TabIndex = 42;
            this.label8.Text = "Phí sinh hoạt";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.Location = new System.Drawing.Point(232, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(224, 37);
            this.label7.TabIndex = 41;
            this.label7.Text = "Tổng tiền nước:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(232, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 37);
            this.label6.TabIndex = 40;
            this.label6.Text = "Tổng tiền điện:";
            // 
            // FormTongTien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp3.Properties.Resources.background;
            this.ClientSize = new System.Drawing.Size(973, 667);
            this.Controls.Add(this.lbXeDuoi15Tan);
            this.Controls.Add(this.lbXeDap);
            this.Controls.Add(this.lbXeMay);
            this.Controls.Add(this.lbTienXe);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lbTienThuePhong);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbNgayLap);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbMaCanHo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbTongTien);
            this.Controls.Add(this.lbPhiSinhHoat);
            this.Controls.Add(this.lbTongTienNuoc);
            this.Controls.Add(this.lbTongTienDien);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Name = "FormTongTien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormTongTien";
            this.Load += new System.EventHandler(this.FormTongTien_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbXeDuoi15Tan;
        private System.Windows.Forms.Label lbXeDap;
        private System.Windows.Forms.Label lbXeMay;
        private System.Windows.Forms.Label lbTienXe;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbTienThuePhong;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbNgayLap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbMaCanHo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbTongTien;
        private System.Windows.Forms.Label lbPhiSinhHoat;
        private System.Windows.Forms.Label lbTongTienNuoc;
        private System.Windows.Forms.Label lbTongTienDien;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
    }
}