﻿namespace DemoLapHopDong
{
    partial class FormLapHopDong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelLHD = new System.Windows.Forms.Label();
            this.lbTenKH = new System.Windows.Forms.Label();
            this.EmailKHlb = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbSDT = new System.Windows.Forms.TextBox();
            this.sdtlb = new System.Windows.Forms.Label();
            this.lbNL = new System.Windows.Forms.Label();
            this.lbNKT = new System.Windows.Forms.Label();
            this.lbSNG = new System.Windows.Forms.Label();
            this.tbSNG = new System.Windows.Forms.TextBox();
            this.dateTimePickerNL = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerNKT = new System.Windows.Forms.DateTimePicker();
            this.Thoát = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tbDC = new System.Windows.Forms.TextBox();
            this.lbDC = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txTen = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelLHD
            // 
            this.labelLHD.AutoSize = true;
            this.labelLHD.BackColor = System.Drawing.Color.PaleTurquoise;
            this.labelLHD.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelLHD.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.labelLHD.Location = new System.Drawing.Point(471, 0);
            this.labelLHD.Name = "labelLHD";
            this.labelLHD.Size = new System.Drawing.Size(281, 49);
            this.labelLHD.TabIndex = 1;
            this.labelLHD.Text = "Lập Hợp Đồng";
            // 
            // lbTenKH
            // 
            this.lbTenKH.AutoSize = true;
            this.lbTenKH.BackColor = System.Drawing.SystemColors.Control;
            this.lbTenKH.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbTenKH.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbTenKH.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbTenKH.Location = new System.Drawing.Point(92, 107);
            this.lbTenKH.Name = "lbTenKH";
            this.lbTenKH.Size = new System.Drawing.Size(143, 37);
            this.lbTenKH.TabIndex = 2;
            this.lbTenKH.Text = "Họ và tên";
            this.lbTenKH.Click += new System.EventHandler(this.lbTenKH_Click);
            // 
            // EmailKHlb
            // 
            this.EmailKHlb.AutoSize = true;
            this.EmailKHlb.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.EmailKHlb.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.EmailKHlb.Location = new System.Drawing.Point(92, 295);
            this.EmailKHlb.Name = "EmailKHlb";
            this.EmailKHlb.Size = new System.Drawing.Size(95, 37);
            this.EmailKHlb.TabIndex = 3;
            this.EmailKHlb.Text = "Email";
            // 
            // tbEmail
            // 
            this.tbEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbEmail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbEmail.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbEmail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbEmail.Location = new System.Drawing.Point(1, 1);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(612, 38);
            this.tbEmail.TabIndex = 5;
            // 
            // tbSDT
            // 
            this.tbSDT.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSDT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSDT.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbSDT.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbSDT.Location = new System.Drawing.Point(1, 1);
            this.tbSDT.Name = "tbSDT";
            this.tbSDT.Size = new System.Drawing.Size(612, 38);
            this.tbSDT.TabIndex = 3;
            // 
            // sdtlb
            // 
            this.sdtlb.AutoSize = true;
            this.sdtlb.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.sdtlb.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.sdtlb.Location = new System.Drawing.Point(92, 169);
            this.sdtlb.Name = "sdtlb";
            this.sdtlb.Size = new System.Drawing.Size(188, 37);
            this.sdtlb.TabIndex = 6;
            this.sdtlb.Text = "Số điện thoại";
            // 
            // lbNL
            // 
            this.lbNL.AutoSize = true;
            this.lbNL.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbNL.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbNL.Location = new System.Drawing.Point(92, 423);
            this.lbNL.Name = "lbNL";
            this.lbNL.Size = new System.Drawing.Size(147, 37);
            this.lbNL.TabIndex = 10;
            this.lbNL.Text = "Ngày Lập";
            this.lbNL.Click += new System.EventHandler(this.lbNL_Click);
            // 
            // lbNKT
            // 
            this.lbNKT.AutoSize = true;
            this.lbNKT.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbNKT.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbNKT.Location = new System.Drawing.Point(92, 496);
            this.lbNKT.Name = "lbNKT";
            this.lbNKT.Size = new System.Drawing.Size(217, 37);
            this.lbNKT.TabIndex = 11;
            this.lbNKT.Text = "Ngày Kết Thúc";
            this.lbNKT.Click += new System.EventHandler(this.lbNKT_Click);
            // 
            // lbSNG
            // 
            this.lbSNG.AutoSize = true;
            this.lbSNG.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbSNG.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbSNG.Location = new System.Drawing.Point(92, 357);
            this.lbSNG.Name = "lbSNG";
            this.lbSNG.Size = new System.Drawing.Size(160, 37);
            this.lbSNG.TabIndex = 7;
            this.lbSNG.Text = "Số người ở";
            // 
            // tbSNG
            // 
            this.tbSNG.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSNG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSNG.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbSNG.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbSNG.Location = new System.Drawing.Point(1, 1);
            this.tbSNG.Name = "tbSNG";
            this.tbSNG.Size = new System.Drawing.Size(612, 38);
            this.tbSNG.TabIndex = 6;
            // 
            // dateTimePickerNL
            // 
            this.dateTimePickerNL.CalendarForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dateTimePickerNL.CalendarTitleForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dateTimePickerNL.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerNL.Location = new System.Drawing.Point(-1, -1);
            this.dateTimePickerNL.Name = "dateTimePickerNL";
            this.dateTimePickerNL.Size = new System.Drawing.Size(618, 45);
            this.dateTimePickerNL.TabIndex = 7;
            this.dateTimePickerNL.ValueChanged += new System.EventHandler(this.dateTimePickerNL_ValueChanged);
            // 
            // dateTimePickerNKT
            // 
            this.dateTimePickerNKT.CalendarForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dateTimePickerNKT.CalendarTitleForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dateTimePickerNKT.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.dateTimePickerNKT.Location = new System.Drawing.Point(-1, -1);
            this.dateTimePickerNKT.Name = "dateTimePickerNKT";
            this.dateTimePickerNKT.Size = new System.Drawing.Size(618, 45);
            this.dateTimePickerNKT.TabIndex = 8;
            this.dateTimePickerNKT.ValueChanged += new System.EventHandler(this.dateTimePickerNKT_ValueChanged);
            // 
            // Thoát
            // 
            this.Thoát.BackColor = System.Drawing.SystemColors.Control;
            this.Thoát.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Thoát.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Thoát.Location = new System.Drawing.Point(340, 611);
            this.Thoát.Name = "Thoát";
            this.Thoát.Size = new System.Drawing.Size(194, 60);
            this.Thoát.TabIndex = 9;
            this.Thoát.Text = "Thoát";
            this.Thoát.UseVisualStyleBackColor = false;
            this.Thoát.Click += new System.EventHandler(this.Thoát_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button1.Location = new System.Drawing.Point(691, 611);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 60);
            this.button1.TabIndex = 10;
            this.button1.Text = "Xác Nhận";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbDC
            // 
            this.tbDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbDC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDC.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.tbDC.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tbDC.Location = new System.Drawing.Point(1, 1);
            this.tbDC.Name = "tbDC";
            this.tbDC.Size = new System.Drawing.Size(612, 38);
            this.tbDC.TabIndex = 4;
            this.tbDC.TextChanged += new System.EventHandler(this.tbDC_TextChanged);
            // 
            // lbDC
            // 
            this.lbDC.AutoSize = true;
            this.lbDC.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lbDC.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbDC.Location = new System.Drawing.Point(92, 225);
            this.lbDC.Name = "lbDC";
            this.lbDC.Size = new System.Drawing.Size(112, 37);
            this.lbDC.TabIndex = 18;
            this.lbDC.Text = "Địa chỉ";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.Thoát);
            this.panel3.Controls.Add(this.labelLHD);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.lbTenKH);
            this.panel3.Controls.Add(this.lbNKT);
            this.panel3.Controls.Add(this.sdtlb);
            this.panel3.Controls.Add(this.lbDC);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.lbNL);
            this.panel3.Controls.Add(this.EmailKHlb);
            this.panel3.Controls.Add(this.lbSNG);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Location = new System.Drawing.Point(448, 183);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1188, 762);
            this.panel3.TabIndex = 11;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.tbSNG);
            this.panel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel9.Location = new System.Drawing.Point(336, 358);
            this.panel9.Name = "panel9";
            this.panel9.Padding = new System.Windows.Forms.Padding(1);
            this.panel9.Size = new System.Drawing.Size(616, 38);
            this.panel9.TabIndex = 24;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.tbDC);
            this.panel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel5.Location = new System.Drawing.Point(336, 226);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(1);
            this.panel5.Size = new System.Drawing.Size(616, 38);
            this.panel5.TabIndex = 19;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.txTen);
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel6.Location = new System.Drawing.Point(336, 107);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(1);
            this.panel6.Size = new System.Drawing.Size(616, 38);
            this.panel6.TabIndex = 20;
            // 
            // txTen
            // 
            this.txTen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txTen.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txTen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txTen.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txTen.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txTen.Location = new System.Drawing.Point(1, 1);
            this.txTen.Name = "txTen";
            this.txTen.Size = new System.Drawing.Size(612, 38);
            this.txTen.TabIndex = 2;
            this.txTen.TextChanged += new System.EventHandler(this.txTen_TextChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.tbSDT);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel4.Location = new System.Drawing.Point(336, 170);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(1);
            this.panel4.Size = new System.Drawing.Size(616, 38);
            this.panel4.TabIndex = 9;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.tbEmail);
            this.panel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel7.Location = new System.Drawing.Point(336, 294);
            this.panel7.Name = "panel7";
            this.panel7.Padding = new System.Windows.Forms.Padding(1);
            this.panel7.Size = new System.Drawing.Size(616, 38);
            this.panel7.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dateTimePickerNL);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel2.Location = new System.Drawing.Point(336, 423);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(1);
            this.panel2.Size = new System.Drawing.Size(618, 45);
            this.panel2.TabIndex = 21;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.dateTimePickerNKT);
            this.panel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.panel8.Location = new System.Drawing.Point(338, 494);
            this.panel8.Name = "panel8";
            this.panel8.Padding = new System.Windows.Forms.Padding(1);
            this.panel8.Size = new System.Drawing.Size(618, 45);
            this.panel8.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.textBox1.Location = new System.Drawing.Point(611, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(685, 57);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "      Search";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button2.Location = new System.Drawing.Point(1316, 80);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(257, 57);
            this.button2.TabIndex = 1;
            this.button2.Text = "Đăng Xuất";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // FormLapHopDong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DemoLapHopDong.Properties.Resources.background;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel3);
            this.Name = "FormLapHopDong";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelLHD;
        private System.Windows.Forms.Label lbTenKH;
        private System.Windows.Forms.Label EmailKHlb;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbSDT;
        private System.Windows.Forms.Label sdtlb;
        private System.Windows.Forms.Label lbNL;
        private System.Windows.Forms.Label lbNKT;
        private System.Windows.Forms.Label lbSNG;
        private System.Windows.Forms.TextBox tbSNG;
        private System.Windows.Forms.DateTimePicker dateTimePickerNL;
        private System.Windows.Forms.DateTimePicker dateTimePickerNKT;
        private System.Windows.Forms.Button Thoát;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbDC;
        private System.Windows.Forms.Label lbDC;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txTen;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
    }
}

